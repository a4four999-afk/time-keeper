bl_info = {
    "name": "文件有效操作时长计时器",
    "author": "Codex",
    "version": (1, 3, 0),
    "blender": (5, 1, 0),
    "location": "3D视图左上角 / 状态栏",
    "description": "只统计当前 blend 文件真正有鼠标键盘操作的有效工作时长，并显示在左上角统计信息下方",
    "category": "System",
}

import time
import os

try:
    import bpy
    import blf
    from bpy.app.handlers import persistent
    from bpy.props import BoolProperty, FloatProperty, IntProperty
except Exception:  # Allows unit tests outside Blender.
    bpy = None
    blf = None
    persistent = lambda func: func
    BoolProperty = FloatProperty = IntProperty = None


IGNORED_EVENTS = {
    "TIMER",
    "MOUSEMOVE",
    "INBETWEEN_MOUSEMOVE",
    "WINDOW_DEACTIVATE",
    "WINDOW_ACTIVATE",
}

VIEWPORT_STATS_FONT_SIZE = 16


def format_duration(seconds):
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def make_display_text(seconds):
    return f"有效操作 {format_duration(seconds)}"


def is_operation_event(event_type):
    if not event_type or event_type in IGNORED_EVENTS:
        return False
    return True


class TrackerState:
    def __init__(self, idle_seconds=60):
        self.idle_seconds = idle_seconds
        self.last_input = None
        self.last_tick = None

    def mark_input(self, now):
        self.last_input = now
        if self.last_tick is None:
            self.last_tick = now

    def tick(self, now):
        if self.last_tick is None:
            self.last_tick = now
            return 0.0
        elapsed = max(0.0, now - self.last_tick)
        self.last_tick = now
        if self.last_input is None:
            return 0.0
        if now - self.last_input <= self.idle_seconds:
            return elapsed
        return 0.0


class InputActivityState:
    """Classify aggregate samples; never record keys, text or other apps' input."""
    def __init__(self):
        self.previous = None

    def observe(self, focused, input_tick, cursor, button_down):
        if not focused:
            self.previous = None
            return False
        previous = self.previous
        self.previous = (input_tick, cursor)
        if previous is None or previous[0] == input_tick:
            return False
        # A click, wheel/key input at a stationary pointer, or a mouse drag.
        # Plain pointer motion remains excluded, as in the original timer.
        return button_down or cursor == previous[1]


class WindowsInputSource:
    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ctypes = ctypes
        self.wintypes = wintypes
        class LastInputInfo(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.UINT), ('dwTime', wintypes.DWORD)]
        self.info = LastInputInfo(ctypes.sizeof(LastInputInfo), 0)
        self.point = wintypes.POINT()
        self.pid = wintypes.DWORD()
        self.user32 = ctypes.WinDLL('user32', use_last_error=True)
        self.kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel32.GetTickCount.argtypes = []
        self.kernel32.GetTickCount.restype = wintypes.DWORD
        for name, args, result in (
            ('GetForegroundWindow', [], wintypes.HWND),
            ('GetWindowThreadProcessId', [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)], wintypes.DWORD),
            ('GetLastInputInfo', [ctypes.POINTER(LastInputInfo)], wintypes.BOOL),
            ('GetCursorPos', [ctypes.POINTER(wintypes.POINT)], wintypes.BOOL),
            ('GetAsyncKeyState', [ctypes.c_int], ctypes.c_short),
        ):
            fn = getattr(self.user32, name)
            fn.argtypes = args
            fn.restype = result
        self.state = InputActivityState()

    def sample(self):
        c = self.ctypes
        foreground = self.user32.GetForegroundWindow()
        self.pid.value = 0
        if foreground:
            self.user32.GetWindowThreadProcessId(foreground, c.byref(self.pid))
        focused = self.pid.value == os.getpid()
        if not focused:
            self.state.observe(False, 0, (0, 0), False)
            return False, False, 0.
        if not self.user32.GetLastInputInfo(c.byref(self.info)) or not self.user32.GetCursorPos(c.byref(self.point)):
            return True, False, 0.
        # Only mouse-button state is inspected; no keyboard contents are read.
        button_down = any(self.user32.GetAsyncKeyState(key) & 0x8000 for key in (1, 2, 4, 5, 6))
        active = self.state.observe(True, self.info.dwTime, (self.point.x, self.point.y), button_down)
        age = ((self.kernel32.GetTickCount() - self.info.dwTime) & 0xffffffff) / 1000.
        return True, active, age


class BlenderActivitySource:
    """Portable fallback observes completed operations and viewport changes."""
    def __init__(self):
        self.previous = None

    def sample(self):
        wm = bpy.context.window_manager
        if not wm or not wm.windows:
            self.previous = None
            return False, False, 0.
        operator = wm.operators[-1].as_pointer() if wm.operators else None
        views = tuple(tuple(v for row in a.spaces.active.region_3d.view_matrix for v in row)
                      for w in wm.windows for a in w.screen.areas
                      if a.type == 'VIEW_3D' and a.spaces.active.region_3d)
        snapshot = (operator, views)
        changed = self.previous is not None and snapshot != self.previous
        self.previous = snapshot
        return True, changed, 0.


if bpy is not None:
    _input_source = None
    _tracker_states = {}
    _last_scene = None
    _status_draw_registered = False
    _viewport_draw_handler = None

    def _scene_has_props(scene):
        return all(hasattr(scene, name) for name in (
            "effective_operation_seconds",
            "effective_operation_enabled",
            "effective_operation_idle_seconds",
            "effective_operation_is_active",
            "effective_operation_overlay_enabled",
            "effective_operation_overlay_x",
            "effective_operation_overlay_y_from_top",
        ))

    def _format_scene_time(scene):
        return format_duration(scene.effective_operation_seconds)

    class WM_OT_effective_operation_timer(bpy.types.Operator):
        bl_idname = "wm.effective_operation_timer"
        bl_label = "文件有效操作时长计时器"
        bl_options = {"INTERNAL"}

        def invoke(self, context, _event):
            return self.execute(context)

        def execute(self, context):
            start_tracker()
            return {'FINISHED'}

    class SCENE_OT_effective_operation_reset(bpy.types.Operator):
        bl_idname = "scene.effective_operation_reset"
        bl_label = "重置有效操作时长"
        bl_description = "重置当前文件保存的有效操作时长"
        bl_options = {"REGISTER", "UNDO"}

        def execute(self, context):
            context.scene.effective_operation_seconds = 0.0
            context.scene.effective_operation_is_active = False
            self.report({"INFO"}, "当前文件有效操作时长已重置")
            return {"FINISHED"}

    def draw_effective_operation_status(self, context):
        scene = context.scene
        if not _scene_has_props(scene) or not scene.effective_operation_enabled:
            return
        icon = "REC" if scene.effective_operation_is_active else "PAUSE"
        self.layout.separator_spacer()
        self.layout.label(text=make_display_text(scene.effective_operation_seconds), icon=icon)

    def draw_effective_operation_viewport():
        if blf is None:
            return

        scene = getattr(bpy.context, "scene", None)
        region = getattr(bpy.context, "region", None)
        if scene is None or region is None:
            return
        if not _scene_has_props(scene):
            return
        if not scene.effective_operation_enabled or not scene.effective_operation_overlay_enabled:
            return

        space = getattr(bpy.context, "space_data", None)
        overlay = getattr(space, "overlay", None)
        if overlay is not None and not getattr(overlay, "show_overlays", True):
            return

        font_id = 0
        x = scene.effective_operation_overlay_x
        y = max(20, region.height - scene.effective_operation_overlay_y_from_top)
        blf.size(font_id, VIEWPORT_STATS_FONT_SIZE)
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        blf.position(font_id, x, y, 0)
        blf.draw(font_id, make_display_text(scene.effective_operation_seconds))

    def poll_tracker():
        global _last_scene
        scene = bpy.context.scene
        if scene is None or not _scene_has_props(scene):
            return .25
        now = time.monotonic()
        pointer = scene.as_pointer()
        state = _tracker_states.setdefault(pointer, TrackerState())
        state.idle_seconds = scene.effective_operation_idle_seconds
        if _last_scene != pointer:
            state.last_input = None
            state.last_tick = now
            _last_scene = pointer
        try:
            focused, operated, input_age = _input_source.sample()
        except Exception:
            focused, operated, input_age = False, False, 0.
        # A render or another blocking operation is not observed editing time.
        if state.last_tick is not None and now - state.last_tick > 2.:
            state.last_tick = now
        if not focused or not scene.effective_operation_enabled:
            state.last_input = None
            state.last_tick = now
        elif operated:
            state.mark_input(now - max(0., input_age))
        added = state.tick(now)
        active = bool(scene.effective_operation_enabled and focused and state.last_input is not None
                      and now - state.last_input <= state.idle_seconds)
        if scene.effective_operation_is_active != active:
            scene.effective_operation_is_active = active
        if active and added > 0:
            scene.effective_operation_seconds += added
        return .25

    def start_tracker():
        global _input_source
        if _input_source is None:
            try:
                _input_source = WindowsInputSource() if os.name == 'nt' else BlenderActivitySource()
            except OSError:
                _input_source = BlenderActivitySource()
        if not bpy.app.timers.is_registered(poll_tracker):
            bpy.app.timers.register(poll_tracker, first_interval=.25, persistent=True)
        return None

    @persistent
    def start_tracker_on_load(_dummy):
        global _input_source, _last_scene
        _input_source = None
        _last_scene = None
        _tracker_states.clear()
        start_tracker()

    classes = (
        WM_OT_effective_operation_timer,
        SCENE_OT_effective_operation_reset,
    )

    def register():
        global _status_draw_registered, _viewport_draw_handler
        for cls in classes:
            bpy.utils.register_class(cls)

        bpy.types.Scene.effective_operation_seconds = FloatProperty(
            name="有效操作时长",
            default=0.0,
            min=0.0,
            options={"SKIP_SAVE"} if False else set(),
        )
        bpy.types.Scene.effective_operation_idle_seconds = IntProperty(
            name="空闲暂停秒数",
            default=60,
            min=5,
            max=3600,
        )
        bpy.types.Scene.effective_operation_enabled = BoolProperty(
            name="启用有效操作计时",
            default=True,
        )
        bpy.types.Scene.effective_operation_is_active = BoolProperty(
            name="正在记录",
            default=False,
            options={"HIDDEN"},
        )
        bpy.types.Scene.effective_operation_overlay_enabled = BoolProperty(
            name="左上角统计下方显示",
            default=True,
        )
        bpy.types.Scene.effective_operation_overlay_x = IntProperty(
            name="左上角 X",
            default=92,
            min=0,
            max=2000,
        )
        bpy.types.Scene.effective_operation_overlay_y_from_top = IntProperty(
            name="距顶部",
            default=390,
            min=40,
            max=2000,
        )

        if hasattr(bpy.types, "STATUSBAR_HT_header") and not _status_draw_registered:
            bpy.types.STATUSBAR_HT_header.append(draw_effective_operation_status)
            _status_draw_registered = True

        if _viewport_draw_handler is None:
            _viewport_draw_handler = bpy.types.SpaceView3D.draw_handler_add(
                draw_effective_operation_viewport,
                (),
                "WINDOW",
                "POST_PIXEL",
            )

        if start_tracker_on_load not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(start_tracker_on_load)
        start_tracker()

    def unregister():
        global _status_draw_registered, _viewport_draw_handler, _input_source, _last_scene
        if bpy.app.timers.is_registered(poll_tracker):
            bpy.app.timers.unregister(poll_tracker)
        _tracker_states.clear()
        _input_source = None
        _last_scene = None
        if hasattr(bpy.types, "STATUSBAR_HT_header") and _status_draw_registered:
            try:
                bpy.types.STATUSBAR_HT_header.remove(draw_effective_operation_status)
            except Exception:
                pass
            _status_draw_registered = False

        if _viewport_draw_handler is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(_viewport_draw_handler, "WINDOW")
            except Exception:
                pass
            _viewport_draw_handler = None

        if start_tracker_on_load in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(start_tracker_on_load)

        for name in (
            "effective_operation_seconds",
            "effective_operation_idle_seconds",
            "effective_operation_enabled",
            "effective_operation_is_active",
            "effective_operation_overlay_enabled",
            "effective_operation_overlay_x",
            "effective_operation_overlay_y_from_top",
        ):
            if hasattr(bpy.types.Scene, name):
                delattr(bpy.types.Scene, name)

        for cls in reversed(classes):
            bpy.utils.unregister_class(cls)

    if __name__ == "__main__":
        register()
